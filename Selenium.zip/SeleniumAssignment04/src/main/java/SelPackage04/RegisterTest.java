package SelPackage04;

	import io.github.bonigarcia.wdm.WebDriverManager;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.Assert;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;

	import java.time.Duration;

	public class RegisterTest {

	    WebDriver driver;

	    @BeforeTest
	    public void setup(){

	        //setup the chrome browser
	        WebDriverManager.chromedriver().setup();
	        driver = new ChromeDriver();

	    }
	    @Test
	    public void login(){

	        //open the url and input the username and password and submit
	        driver.get("https://demo.guru99.com/insurance/v1/index.php");
	        driver.findElement(By.id("email")).sendKeys("sivatharshan81@gmail.com");
	        driver.findElement(By.id("password")).sendKeys("5001384Tharshan");
	        driver.findElement(By.name("submit")).click();

	        //explicit wait for the element to be visible
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\"content\"]//h4")));

	        //Assertion for validate login
	        Assert.assertEquals(driver.findElement(By.xpath("//div[@class=\"content\"]//h4")).getText(),"sivatharshan81@gmail.com");

	    }

	    @AfterTest
	    public void teardown(){

	        //close and quit the browser
	        driver.close();
	        driver.quit();

	    }
	}
